mkdir Float_Test_stats
sar -u 1 >> Float_Test_stats/cpu_data.csv |sar -r 1 >>Float_Test_stats/memory_data.csv | sar -S 1 >> Float_Test_stats/swap_data.csv | python Float_test.py >> Data.docx
echo " Float Test Completed"
sleep 10
cp cpu_data_report.py memory_data.py swap_data.py processed-list.py Float_Test_stats/
cd Float_Test_stats/
python cpu_data_report.py >> ../Data.docx
python memory_data.py >> ../Data.docx
python swap_data.py >> ../Data.docx
python processed-list.py
echo " Data Processed"
cd ..
