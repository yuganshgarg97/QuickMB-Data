apt update
apt upgrade
apt install python3
update-alternatives --install  /usr/bin/python python /usr/bin/python3 10
apt install sysstat
apt install net-tools
apt install network-manager
sudo apt-get install speedtest-cli
apt update
apt upgrade
